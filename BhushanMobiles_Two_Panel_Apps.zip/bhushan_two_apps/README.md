# BHUSHAN MOBILES – Two Android Apps

This package contains two separate Android Studio projects:
- CustomerApp: customer login/OTP, home, repair booking, accessories, online services, payments, orders and profile.
- AdminApp: owner/admin login, dashboard, repair bookings, service requests, products, orders/payments and notifications.

Both are designed for Telugu + English. The projects use demo/local flows; connect Firebase Authentication/Firestore (or another backend) and a payment gateway for production OTP, synchronized data and live payments.

Open each folder separately in Android Studio and build the corresponding APK.
