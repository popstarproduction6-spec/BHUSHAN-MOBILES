package com.bhushanmobiles.customer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b);setContent{CustomerApp()}} }
@Composable fun CustomerApp(){ var telugu by remember{mutableStateOf(false)}; var screen by remember{mutableStateOf("home")}; MaterialTheme{ Scaffold(bottomBar={NavigationBar{listOf("Home" to Icons.Default.Home,"Repair" to Icons.Default.Build,"Accessories" to Icons.Default.ShoppingCart,"Services" to Icons.Default.Description,"Profile" to Icons.Default.Person).forEach{(n,i)->NavigationBarItem(selected=screen==n.lowercase(),onClick={screen=n.lowercase()},icon={Icon(i,null)},label={Text(if(telugu) mapOf("Home" to "హోమ్","Repair" to "రిపేర్","Accessories" to "యాక్సెసరీస్","Services" to "సేవలు","Profile" to "ప్రొఫైల్")[n]!! else n)})}}}){p->Column(Modifier.fillMaxSize().padding(p).padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("BHUSHAN MOBILES",style=MaterialTheme.typography.headlineSmall);TextButton({telugu=!telugu}){Text(if(telugu)"English" else "తెలుగు")}};when(screen){"home"->Home(telugu){screen="repair"};"repair"->Repair(telugu);"accessories"->ListScreen(if(telugu)"యాక్సెసరీస్" else "Accessories",listOf("Tempered Glass","Chargers","Cables","Earphones"));"services"->ListScreen(if(telugu)"ఆన్‌లైన్ సేవలు" else "Online Services",listOf("Aadhaar Service","PAN Card Service","Voter ID Service","MeeSeva Services"));else->Profile(telugu)}}}}
@Composable fun Home(t:Boolean,go:()->Unit){LazyColumn(verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text(if(t)"మీ మొబైల్ అవసరాలన్నీ ఒకే చోట" else "All your mobile needs in one place",style=MaterialTheme.typography.headlineMedium)};item{Button(go,Modifier.fillMaxWidth()){Text(if(t)"మొబైల్ రిపేర్ బుక్ చేయండి" else "Book Mobile Repair")}};items(listOf(if(t)"యాక్సెసరీస్" else "Accessories",if(t)"ఆన్‌లైన్ సేవలు" else "Online Services",if(t)"పేమెంట్స్" else "Payments",if(t)"నా ఆర్డర్లు" else "My Orders")){Card(Modifier.fillMaxWidth()){Text(it,Modifier.padding(22.dp),style=MaterialTheme.typography.titleLarge)}}}}
@Composable fun Repair(t:Boolean){var brand by remember{mutableStateOf("")};var issue by remember{mutableStateOf("")};Text(if(t)"మొబైల్ రిపేర్ బుకింగ్" else "Mobile Repair Booking",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));OutlinedTextField(brand,{brand=it},Modifier.fillMaxWidth(),label={Text(if(t)"మొబైల్ బ్రాండ్" else "Mobile Brand")});Spacer(Modifier.height(8.dp));OutlinedTextField(issue,{issue=it},Modifier.fillMaxWidth(),label={Text(if(t)"సమస్య" else "Problem")});Spacer(Modifier.height(12.dp));Button({},Modifier.fillMaxWidth()){Text(if(t)"బుక్ చేయండి" else "Book Now")}}
@Composable fun ListScreen(title:String,items:List<String>){Text(title,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));items.forEach{Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Check,null);Spacer(Modifier.width(12.dp));Text(it)}}}}
@Composable fun Profile(t:Boolean){Text(if(t)"ప్రొఫైల్ & లాగిన్" else "Profile & Login",style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.height(12.dp));OutlinedTextField("",{},Modifier.fillMaxWidth(),label={Text(if(t)"మొబైల్ నంబర్" else "Mobile Number")});Spacer(Modifier.height(8.dp));Button({},Modifier.fillMaxWidth()){Text(if(t)"OTP పొందండి" else "Get OTP")}}
